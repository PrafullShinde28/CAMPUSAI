import { useState } from 'react';
import { useMutation } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { api } from '@/lib/api';

export default function LearningBuddy() {
  const [selectedText, setSelectedText] = useState('');
  const [context, setContext] = useState('');
  const [explanation, setExplanation] = useState('');
  const [sampleTexts] = useState([
    {
      title: "Quantum Mechanics",
      content: "The uncertainty principle states that the more precisely the position of some particle is determined, the less precisely its momentum can be predicted from initial conditions."
    },
    {
      title: "Photosynthesis", 
      content: "Photosynthesis is the process by which plants use sunlight, water, and carbon dioxide to create oxygen and energy in the form of sugar."
    },
    {
      title: "Supply and Demand",
      content: "In economics, supply and demand is a model of price determination in a market. It postulates that the unit price for a particular good will vary until it settles at a point where the quantity demanded equals the quantity supplied."
    }
  ]);

  const { toast } = useToast();

  const explainMutation = useMutation({
    mutationFn: async ({ text, context }: { text: string; context?: string }) => {
      const response = await api.explainText({ text, context });
      return response.json();
    },
    onSuccess: (data) => {
      setExplanation(data.explanation);
      toast({ title: "Success", description: "Explanation generated!" });
    },
    onError: (error) => {
      toast({ title: "Error", description: "Failed to generate explanation" });
    },
  });

  const handleExplain = () => {
    if (selectedText.trim()) {
      explainMutation.mutate({ text: selectedText, context });
    }
  };

  const handleSampleClick = (content: string) => {
    setSelectedText(content);
    setExplanation('');
  };

  return (
    <div className="space-y-6" data-testid="learning-buddy">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Contextual Learning Buddy</h1>
          <p className="text-muted-foreground">Get instant AI explanations for any text</p>
        </div>
        <Badge variant="secondary" className="bg-accent text-accent-foreground">
          <i className="fas fa-robot mr-1"></i>
          Powered by Gemini
        </Badge>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Input Section */}
        <div className="space-y-6">
          <Card data-testid="text-input-card">
            <CardHeader>
              <CardTitle>Text to Explain</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Textarea
                  placeholder="Paste or type any text you want explained..."
                  value={selectedText}
                  onChange={(e) => setSelectedText(e.target.value)}
                  rows={6}
                  data-testid="textarea-text-input"
                />
              </div>

              <div>
                <label className="text-sm font-medium text-foreground mb-2 block">
                  Additional Context (Optional)
                </label>
                <Textarea
                  placeholder="Provide any additional context that might help with the explanation..."
                  value={context}
                  onChange={(e) => setContext(e.target.value)}
                  rows={3}
                  data-testid="textarea-context"
                />
              </div>

              <Button 
                onClick={handleExplain}
                disabled={!selectedText.trim() || explainMutation.isPending}
                className="w-full"
                data-testid="button-explain"
              >
                {explainMutation.isPending ? (
                  <>
                    <i className="fas fa-spinner fa-spin mr-2"></i>
                    Generating Explanation...
                  </>
                ) : (
                  <>
                    <i className="fas fa-lightbulb mr-2"></i>
                    Explain This Text
                  </>
                )}
              </Button>
            </CardContent>
          </Card>

          {/* Sample Texts */}
          <Card data-testid="sample-texts-card">
            <CardHeader>
              <CardTitle>Try These Examples</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {sampleTexts.map((sample, index) => (
                <div 
                  key={index}
                  className="p-3 border border-border rounded-lg cursor-pointer hover:bg-muted transition-colors"
                  onClick={() => handleSampleClick(sample.content)}
                  data-testid={`sample-text-${index}`}
                >
                  <h3 className="font-medium text-foreground text-sm mb-1">{sample.title}</h3>
                  <p className="text-xs text-muted-foreground line-clamp-2">{sample.content}</p>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>

        {/* Explanation Section */}
        <div>
          <Card data-testid="explanation-card">
            <CardHeader>
              <CardTitle>AI Explanation</CardTitle>
            </CardHeader>
            <CardContent>
              {explanation ? (
                <div className="prose prose-sm max-w-none" data-testid="explanation-content">
                  <div className="whitespace-pre-wrap text-foreground">{explanation}</div>
                </div>
              ) : (
                <div className="text-center py-12" data-testid="no-explanation-message">
                  <i className="fas fa-lightbulb text-4xl text-muted-foreground mb-4"></i>
                  <p className="text-muted-foreground">
                    Enter some text and click "Explain This Text" to get an AI-powered explanation
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>

      {/* How it Works */}
      <Card data-testid="how-it-works-card">
        <CardHeader>
          <CardTitle>How Learning Buddy Works</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mx-auto mb-3">
                <i className="fas fa-paste text-blue-600 text-xl"></i>
              </div>
              <h3 className="font-medium text-foreground mb-2">1. Input Text</h3>
              <p className="text-sm text-muted-foreground">
                Paste or type any text you want to understand better
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mx-auto mb-3">
                <i className="fas fa-brain text-purple-600 text-xl"></i>
              </div>
              <h3 className="font-medium text-foreground mb-2">2. AI Analysis</h3>
              <p className="text-sm text-muted-foreground">
                Our AI analyzes the text and generates comprehensive explanations
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mx-auto mb-3">
                <i className="fas fa-graduation-cap text-green-600 text-xl"></i>
              </div>
              <h3 className="font-medium text-foreground mb-2">3. Learn & Understand</h3>
              <p className="text-sm text-muted-foreground">
                Get clear explanations, examples, and related concepts
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
