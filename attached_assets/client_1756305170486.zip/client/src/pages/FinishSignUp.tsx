import React, { useEffect, useState } from "react";
import { getAuth, isSignInWithEmailLink, signInWithEmailLink } from "firebase/auth";

export default function FinishSignUp() {
  const [message, setMessage] = useState("");

  useEffect(() => {
    const auth = getAuth();
    if (isSignInWithEmailLink(auth, window.location.href)) {
      let email = window.localStorage.getItem("emailForSignIn");
      if (!email) {
        email = window.prompt("Please provide your email for confirmation");
      }
      signInWithEmailLink(auth, email!, window.location.href)
        .then(() => {
          window.localStorage.removeItem("emailForSignIn");
          setMessage("Signed in successfully!");
        })
        .catch((error: any) => {
          setMessage(error.message);
        });
    }
  }, []);

  return (
    <div>
      <h2>Finish Sign-Up</h2>
      <div>{message}</div>
    </div>
  );
}