import { Link, useLocation } from 'wouter';
import { useAuth } from '@/hooks/useAuth';

export function Sidebar() {
  const [location] = useLocation();
  const { userData, logout } = useAuth();

  const navigationItems = [
    { path: '/', icon: 'fas fa-home', label: 'Dashboard' },
    { path: '/study-planner', icon: 'fas fa-calendar-alt', label: 'Study Planner', badge: 'AI' },
    { path: '/quiz-generator', icon: 'fas fa-question-circle', label: 'Quiz Generator', badge: 'AI' },
    { path: '/learning-buddy', icon: 'fas fa-lightbulb', label: 'Learning Buddy', badge: 'AI' },
    { path: '/idea-marketplace', icon: 'fas fa-store', label: 'Idea Marketplace' },
    { path: '/peer-matchmaker', icon: 'fas fa-users', label: 'Peer Matchmaker' },
  ];

  return (
    <aside className="w-64 bg-card border-r border-border flex flex-col" data-testid="sidebar">
      {/* Logo Section */}
      <div className="p-6 border-b border-border">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-lg gradient-bg flex items-center justify-center">
            <i className="fas fa-graduation-cap text-primary-foreground text-xl"></i>
          </div>
          <div>
            <h1 className="text-xl font-bold text-foreground">CampusAI</h1>
            <p className="text-sm text-muted-foreground">AI-Powered Learning</p>
          </div>
        </div>
      </div>
      
      {/* Navigation */}
      <nav className="flex-1 p-4">
        <div className="space-y-2">
          {navigationItems.map((item) => (
            <Link key={item.path} href={item.path}>
              <a 
                className={`flex items-center space-x-3 px-4 py-3 rounded-lg font-medium transition-colors ${
                  location === item.path
                    ? 'bg-primary text-primary-foreground'
                    : 'text-muted-foreground hover:bg-muted hover:text-foreground'
                }`}
                data-testid={`nav-${item.label.toLowerCase().replace(' ', '-')}`}
              >
                <i className={`${item.icon} text-lg`}></i>
                <span>{item.label}</span>
                {item.badge && (
                  <span className="ml-auto bg-accent text-accent-foreground text-xs px-2 py-1 rounded-full">
                    {item.badge}
                  </span>
                )}
              </a>
            </Link>
          ))}
          
          {/* Google Classroom Integration */}
          <div className="pt-4 pb-2">
            <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider px-4">
              Integrations
            </h3>
          </div>
          
          <div className="flex items-center space-x-3 px-4 py-3 rounded-lg text-muted-foreground">
            <i className="fab fa-google text-lg"></i>
            <span>Google Classroom</span>
            <span className="ml-auto text-xs text-green-600">Connected</span>
          </div>
        </div>
      </nav>
      
      {/* User Profile Section */}
      <div className="p-4 border-t border-border">
        <div className="flex items-center space-x-3 px-4 py-3 rounded-lg hover:bg-muted transition-colors cursor-pointer group">
          <img 
            src={userData?.avatar || "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100"} 
            alt="User profile picture" 
            className="w-10 h-10 rounded-full border-2 border-border"
            data-testid="user-avatar"
          />
          <div className="flex-1 min-w-0">
            <p className="font-medium text-foreground truncate" data-testid="user-name">
              {userData?.name || 'User'}
            </p>
            <p className="text-sm text-muted-foreground truncate" data-testid="user-email">
              {userData?.email || 'user@example.com'}
            </p>
          </div>
          <button 
            onClick={logout}
            className="opacity-0 group-hover:opacity-100 transition-opacity"
            data-testid="logout-button"
          >
            <i className="fas fa-sign-out-alt text-muted-foreground"></i>
          </button>
        </div>
      </div>
    </aside>
  );
}
