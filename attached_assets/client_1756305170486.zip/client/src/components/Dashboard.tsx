import { useQuery } from '@tanstack/react-query';
import { api } from '@/lib/api';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Link } from 'wouter';

export function Dashboard() {
  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: ['/api/dashboard/stats'],
    queryFn: async () => {
      const response = await api.getDashboardStats();
      return response.json();
    },
  });

  const { data: ideas, isLoading: ideasLoading } = useQuery({
    queryKey: ['/api/ideas'],
    queryFn: async () => {
      const response = await api.getIdeas();
      return response.json();
    },
  });

  if (statsLoading) {
    return (
      <div className="space-y-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[...Array(4)].map((_, i) => (
            <Skeleton key={i} className="h-32" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8" data-testid="dashboard">
      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="feature-card cursor-pointer" data-testid="stat-study-streak">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Study Streak</p>
                <p className="text-2xl font-bold text-foreground">{stats?.studyStreak || 0} Days</p>
                <p className="text-xs text-green-600 flex items-center mt-1">
                  <i className="fas fa-arrow-up mr-1"></i>
                  Keep it up!
                </p>
              </div>
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                <i className="fas fa-fire text-green-600 text-xl"></i>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="feature-card cursor-pointer" data-testid="stat-quiz-score">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Quiz Score</p>
                <p className="text-2xl font-bold text-foreground">{stats?.avgQuizScore || 0}%</p>
                <p className="text-xs text-blue-600 flex items-center mt-1">
                  <i className="fas fa-arrow-up mr-1"></i>
                  Average this month
                </p>
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                <i className="fas fa-chart-line text-blue-600 text-xl"></i>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="feature-card cursor-pointer" data-testid="stat-study-hours">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Study Hours</p>
                <p className="text-2xl font-bold text-foreground">{stats?.weeklyStudyHours || 0}h</p>
                <p className="text-xs text-purple-600 flex items-center mt-1">
                  <i className="fas fa-clock mr-1"></i>
                  This week
                </p>
              </div>
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                <i className="fas fa-clock text-purple-600 text-xl"></i>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="feature-card cursor-pointer" data-testid="stat-active-projects">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Active Projects</p>
                <p className="text-2xl font-bold text-foreground">{stats?.activeProjects || 0}</p>
                <p className="text-xs text-orange-600 flex items-center mt-1">
                  <i className="fas fa-project-diagram mr-1"></i>
                  In progress
                </p>
              </div>
              <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
                <i className="fas fa-tasks text-orange-600 text-xl"></i>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Main Feature Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
        {/* AI Study Planner */}
        <Card className="feature-card cursor-pointer" data-testid="card-study-planner">
          <CardContent className="p-6">
            <div className="flex items-start justify-between mb-4">
              <div className="w-12 h-12 gradient-bg rounded-lg flex items-center justify-center">
                <i className="fas fa-robot text-white text-xl"></i>
              </div>
              <span className="bg-accent text-accent-foreground text-xs px-2 py-1 rounded-full">AI Powered</span>
            </div>
            <h3 className="text-lg font-semibold text-foreground mb-2">AI Study Planner</h3>
            <p className="text-muted-foreground text-sm mb-4">
              Generate personalized study schedules using advanced AI. Optimize your learning path based on your goals and available time.
            </p>
            <div className="flex items-center justify-between">
              <span className="text-xs text-muted-foreground">Powered by Gemini</span>
              <Link href="/study-planner">
                <Button variant="ghost" className="text-primary hover:text-primary/80 p-0 h-auto">
                  Create Plan →
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
        
        {/* Quiz Generator */}
        <Card className="feature-card cursor-pointer" data-testid="card-quiz-generator">
          <CardContent className="p-6">
            <div className="flex items-start justify-between mb-4">
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                <i className="fas fa-question-circle text-green-600 text-xl"></i>
              </div>
              <span className="bg-green-100 text-green-700 text-xs px-2 py-1 rounded-full">Ready</span>
            </div>
            <h3 className="text-lg font-semibold text-foreground mb-2">Adaptive Quiz Generator</h3>
            <p className="text-muted-foreground text-sm mb-4">
              Create custom quizzes from any topic. AI adapts difficulty based on your performance and learning progress.
            </p>
            <div className="flex items-center justify-between">
              <span className="text-xs text-muted-foreground">AI-Generated</span>
              <Link href="/quiz-generator">
                <Button variant="ghost" className="text-primary hover:text-primary/80 p-0 h-auto">
                  Generate Quiz →
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
        
        {/* Learning Buddy */}
        <Card className="feature-card cursor-pointer" data-testid="card-learning-buddy">
          <CardContent className="p-6">
            <div className="flex items-start justify-between mb-4">
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                <i className="fas fa-lightbulb text-purple-600 text-xl"></i>
              </div>
              <span className="bg-purple-100 text-purple-700 text-xs px-2 py-1 rounded-full">Interactive</span>
            </div>
            <h3 className="text-lg font-semibold text-foreground mb-2">Contextual Learning Buddy</h3>
            <p className="text-muted-foreground text-sm mb-4">
              Highlight any text to get instant AI explanations, examples, and related concepts to deepen your understanding.
            </p>
            <div className="flex items-center justify-between">
              <span className="text-xs text-muted-foreground">Smart Assistant</span>
              <Link href="/learning-buddy">
                <Button variant="ghost" className="text-primary hover:text-primary/80 p-0 h-auto">
                  Try Now →
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Community Features */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Idea Marketplace */}
        <Card data-testid="card-idea-marketplace">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-foreground">Idea Marketplace</h3>
              <Link href="/idea-marketplace">
                <Button variant="ghost" className="text-primary hover:text-primary/80 p-0 h-auto">
                  View All →
                </Button>
              </Link>
            </div>
            <p className="text-muted-foreground text-sm mb-4">
              Discover and collaborate on innovative project ideas from students worldwide.
            </p>
            
            {/* Featured Ideas */}
            <div className="space-y-3">
              {ideasLoading ? (
                <Skeleton className="h-20" />
              ) : (
                ideas?.slice(0, 2).map((idea: any) => (
                  <div key={idea.id} className="flex items-start space-x-3 p-3 bg-muted rounded-lg">
                    <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                      <i className="fas fa-lightbulb text-blue-600"></i>
                    </div>
                    <div className="flex-1 min-w-0">
                      <h4 className="font-medium text-foreground text-sm">{idea.title}</h4>
                      <p className="text-xs text-muted-foreground mt-1">
                        {idea.category} • {idea.likes || 0} likes
                      </p>
                      <div className="flex items-center space-x-2 mt-2">
                        <span className="bg-green-100 text-green-700 text-xs px-2 py-1 rounded">
                          {idea.status}
                        </span>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
            
            <Link href="/idea-marketplace">
              <Button className="w-full mt-4" data-testid="button-submit-idea">
                Submit New Idea
              </Button>
            </Link>
          </CardContent>
        </Card>
        
        {/* Peer Matchmaker */}
        <Card data-testid="card-peer-matchmaker">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-foreground">Study Partners</h3>
              <Link href="/peer-matchmaker">
                <Button variant="ghost" className="text-primary hover:text-primary/80 p-0 h-auto">
                  Find More →
                </Button>
              </Link>
            </div>
            <p className="text-muted-foreground text-sm mb-4">
              Connect with peers for study sessions and collaborative learning.
            </p>
            
            {/* Mock Matched Peers */}
            <div className="space-y-3">
              <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
                <div className="flex items-center space-x-3">
                  <img 
                    src="https://pixabay.com/get/gabd5fdee31f4a075a5d0790607d1745d6cc913f10d2c9aed4c26c8d1f2444f0414c717baab5bb13ab571e7efd875f33cdc0984811594b29f308976a0ead56e0b_1280.jpg" 
                    alt="Sarah Chen profile picture" 
                    className="w-10 h-10 rounded-full"
                  />
                  <div>
                    <h4 className="font-medium text-foreground text-sm">Sarah Chen</h4>
                    <p className="text-xs text-muted-foreground">Mathematics • 94% compatibility</p>
                  </div>
                </div>
                <Button size="sm" variant="outline" className="text-xs">
                  Message
                </Button>
              </div>
              
              <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
                <div className="flex items-center space-x-3">
                  <img 
                    src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100" 
                    alt="Marcus Johnson profile picture" 
                    className="w-10 h-10 rounded-full"
                  />
                  <div>
                    <h4 className="font-medium text-foreground text-sm">Marcus Johnson</h4>
                    <p className="text-xs text-muted-foreground">Physics • 89% compatibility</p>
                  </div>
                </div>
                <Button size="sm" variant="outline" className="text-xs">
                  Connect
                </Button>
              </div>
            </div>
            
            <Link href="/peer-matchmaker">
              <Button variant="secondary" className="w-full mt-4">
                Update Preferences
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>
      
      {/* Quick Actions */}
      <Card data-testid="card-quick-actions">
        <CardContent className="p-6">
          <h3 className="text-lg font-semibold text-foreground mb-4">Quick Actions</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Button className="flex items-center space-x-2 p-4 h-auto" data-testid="button-start-session">
              <i className="fas fa-play-circle"></i>
              <span>Start Study Session</span>
            </Button>
            
            <Link href="/study-planner">
              <Button variant="outline" className="flex items-center space-x-2 p-4 h-auto w-full">
                <i className="fas fa-calendar-plus"></i>
                <span>Schedule Study Time</span>
              </Button>
            </Link>
            
            <Link href="/quiz-generator">
              <Button variant="outline" className="flex items-center space-x-2 p-4 h-auto w-full">
                <i className="fas fa-brain"></i>
                <span>Take Practice Quiz</span>
              </Button>
            </Link>
            
            <Link href="/peer-matchmaker">
              <Button variant="outline" className="flex items-center space-x-2 p-4 h-auto w-full">
                <i className="fas fa-search"></i>
                <span>Find Study Partner</span>
              </Button>
            </Link>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
