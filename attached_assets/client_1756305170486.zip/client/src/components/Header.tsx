import { useState } from 'react';
import { useAuth } from '@/hooks/useAuth';

export function Header() {
  const { userData } = useAuth();
  const [isDark, setIsDark] = useState(false);

  const toggleTheme = () => {
    setIsDark(!isDark);
    document.documentElement.classList.toggle('dark');
  };

  return (
    <header className="bg-card border-b border-border px-6 py-4" data-testid="header">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-foreground" data-testid="welcome-message">
            Welcome back, {userData?.name?.split(' ')[0] || 'Student'}!
          </h2>
          <p className="text-muted-foreground mt-1">
            Here's what's happening with your studies today
          </p>
        </div>
        
        <div className="flex items-center space-x-4">
          {/* Notifications */}
          <button 
            className="relative p-2 text-muted-foreground hover:text-foreground hover:bg-muted rounded-lg transition-colors"
            data-testid="notifications-button"
          >
            <i className="fas fa-bell text-xl"></i>
            <span className="absolute -top-1 -right-1 w-5 h-5 bg-destructive text-destructive-foreground text-xs rounded-full flex items-center justify-center">
              3
            </span>
          </button>
          
          {/* Theme Toggle */}
          <button 
            onClick={toggleTheme}
            className="p-2 text-muted-foreground hover:text-foreground hover:bg-muted rounded-lg transition-colors"
            data-testid="theme-toggle"
          >
            <i className={`fas ${isDark ? 'fa-sun' : 'fa-moon'} text-xl`}></i>
          </button>
        </div>
      </div>
    </header>
  );
}
