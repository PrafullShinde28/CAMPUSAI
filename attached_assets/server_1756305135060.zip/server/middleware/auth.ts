import type { Request, Response, NextFunction } from "express";
import { firebaseService } from "../services/firebase";

// Verifies Firebase ID token from Authorization: Bearer <token>
export async function authMiddleware(req: Request, res: Response, next: NextFunction) {
  try {
    const authHeader = req.headers.authorization || "";
    const parts = authHeader.split(" ");
    if (parts.length !== 2 || parts[0] !== "Bearer") {
      return res.status(401).json({ message: "Missing or invalid Authorization header" });
    }

    const idToken = parts[1];
    const decoded = await firebaseService.verifyIdToken(idToken);

    // For backward compatibility with existing code that reads x-user-id
    req.headers["x-user-id"] = decoded.uid as any;
    // Attach firebase user on request for routes that need more info
    (req as any).firebaseUser = decoded;

    next();
  } catch (err: any) {
    return res.status(401).json({ message: "Unauthorized", error: err?.message });
  }
}

