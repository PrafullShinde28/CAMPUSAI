# Overview

CampusAI is an AI-powered learning platform that provides comprehensive educational tools for students. The application offers six core features: a dashboard with study analytics, an AI-powered study planner, a quiz generator, a learning buddy for text explanations, an idea marketplace for sharing concepts, and a peer matchmaker for finding study partners. Built as a full-stack web application, it combines modern React frontend technologies with a robust Node.js backend and PostgreSQL database.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React 18 with TypeScript for type safety and modern development patterns
- **Routing**: Wouter for lightweight client-side routing without the complexity of React Router
- **State Management**: TanStack Query (React Query) for server state management, caching, and synchronization
- **UI Components**: Shadcn/ui component library built on Radix UI primitives for accessibility and consistency
- **Styling**: Tailwind CSS with custom CSS variables for theming and responsive design
- **Build Tool**: Vite for fast development and optimized production builds

## Backend Architecture
- **Runtime**: Node.js with Express.js framework for RESTful API endpoints
- **Language**: TypeScript with ES modules for modern JavaScript features
- **Database ORM**: Drizzle ORM for type-safe database operations and schema management
- **Development Server**: Custom Vite integration for hot module replacement in development

## Authentication System
- **Provider**: Firebase Authentication with Google OAuth integration
- **Session Management**: Custom user session handling with database user synchronization
- **Authorization**: Header-based user identification for API requests

## Database Design
- **Database**: PostgreSQL with Neon serverless hosting
- **Schema Management**: Drizzle Kit for migrations and schema evolution
- **Connection**: Connection pooling with @neondatabase/serverless for optimal performance
- **Tables**: Users, study plans, quizzes, quiz attempts, ideas, study sessions, and peer matches

## AI Integration
- **Provider**: Google Gemini AI for natural language processing and content generation
- **Use Cases**: 
  - Study plan generation based on subjects, hours, and goals
  - Quiz question creation with multiple choice answers and explanations
  - Text explanation and concept clarification
  - Peer matching algorithm enhancement

## External Dependencies

- **AI Services**: Google Gemini API for content generation and natural language processing
- **Authentication**: Firebase Auth for Google OAuth and user management
- **Database**: Neon PostgreSQL for serverless database hosting
- **Deployment**: Replit for development and hosting environment
- **UI Libraries**: Radix UI primitives for accessible component foundations
- **Styling**: Tailwind CSS for utility-first styling approach
- **Development Tools**: ESBuild for production bundling and TypeScript compilation