import React, { useState } from "react";
import { getAuth, sendSignInLinkToEmail } from "firebase/auth";

export default function EmailLinkSignIn() {
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");

  const handleSendLink = async () => {
    const auth = getAuth();
    const actionCodeSettings = {
      url: "http://localhost:5000/finishSignUp", // Change if needed
      handleCodeInApp: true,
    };
    try {
      await sendSignInLinkToEmail(auth, email, actionCodeSettings);
      window.localStorage.setItem("emailForSignIn", email);
      setMessage("Sign-in link sent! Check your email.");
    } catch (error: any) {
      setMessage(error.message);
    }
  };

  return (
    <div>
      <h2>Email Link Sign-In</h2>
      <input
        type="email"
        placeholder="Your email"
        value={email}
        onChange={e => setEmail(e.target.value)}
      />
      <button onClick={handleSendLink}>Send Sign-In Link</button>
      <div>{message}</div>
    </div>
  );
}