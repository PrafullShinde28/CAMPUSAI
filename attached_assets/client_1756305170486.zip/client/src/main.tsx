import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";
import { initMessaging } from "./services/messaging";

createRoot(document.getElementById("root")!).render(<App />);

// Initialize Firebase Cloud Messaging (non-blocking)
initMessaging().catch(() => {});
