import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { useToast } from '@/hooks/use-toast';
import { api } from '@/lib/api';

export default function QuizGenerator() {
  const [isGenerating, setIsGenerating] = useState(false);
  const [activeQuiz, setActiveQuiz] = useState<any>(null);
  const [userAnswers, setUserAnswers] = useState<number[]>([]);
  const [showResults, setShowResults] = useState(false);
  const [formData, setFormData] = useState({
    topic: '',
    difficulty: 'medium',
    questionCount: 5
  });

  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: quizzes, isLoading } = useQuery({
    queryKey: ['/api/quizzes'],
    queryFn: async () => {
      const response = await api.getQuizzes();
      return response.json();
    },
  });

  const generateQuizMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await api.generateQuiz(data);
      return response.json();
    },
    onSuccess: (quiz) => {
      queryClient.invalidateQueries({ queryKey: ['/api/quizzes'] });
      setActiveQuiz(quiz);
      setUserAnswers(new Array(quiz.questions.length).fill(-1));
      setShowResults(false);
      toast({ title: "Success", description: "Quiz generated successfully!" });
      setIsGenerating(false);
    },
    onError: (error) => {
      toast({ title: "Error", description: "Failed to generate quiz" });
      setIsGenerating(false);
    },
  });

  const submitQuizMutation = useMutation({
    mutationFn: async ({ quizId, answers }: { quizId: string; answers: number[] }) => {
      const response = await api.submitQuizAttempt(quizId, { answers });
      return response.json();
    },
    onSuccess: (result) => {
      setShowResults(true);
      toast({ 
        title: "Quiz Complete", 
        description: `You scored ${result.score}%!` 
      });
    },
    onError: (error) => {
      toast({ title: "Error", description: "Failed to submit quiz" });
    },
  });

  const handleGenerateQuiz = async () => {
    setIsGenerating(true);
    generateQuizMutation.mutate(formData);
  };

  const handleAnswerChange = (questionIndex: number, answerIndex: number) => {
    setUserAnswers(prev => {
      const newAnswers = [...prev];
      newAnswers[questionIndex] = answerIndex;
      return newAnswers;
    });
  };

  const handleSubmitQuiz = () => {
    if (activeQuiz && userAnswers.every(answer => answer !== -1)) {
      submitQuizMutation.mutate({
        quizId: activeQuiz.id,
        answers: userAnswers
      });
    }
  };

  const startNewQuiz = () => {
    setActiveQuiz(null);
    setUserAnswers([]);
    setShowResults(false);
  };

  return (
    <div className="space-y-6" data-testid="quiz-generator">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Adaptive Quiz Generator</h1>
          <p className="text-muted-foreground">Create AI-powered quizzes on any topic</p>
        </div>
        <Badge variant="secondary" className="bg-accent text-accent-foreground">
          <i className="fas fa-robot mr-1"></i>
          Powered by Gemini
        </Badge>
      </div>

      {!activeQuiz ? (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Quiz Generator Form */}
          <div className="lg:col-span-1">
            <Card data-testid="quiz-generator-form">
              <CardHeader>
                <CardTitle>Generate New Quiz</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="topic">Topic</Label>
                  <Input
                    id="topic"
                    placeholder="e.g., Calculus, World History, Biology"
                    value={formData.topic}
                    onChange={(e) => setFormData(prev => ({ ...prev, topic: e.target.value }))}
                    data-testid="input-topic"
                  />
                </div>

                <div>
                  <Label htmlFor="difficulty">Difficulty</Label>
                  <Select 
                    value={formData.difficulty} 
                    onValueChange={(value) => setFormData(prev => ({ ...prev, difficulty: value }))}
                  >
                    <SelectTrigger data-testid="select-difficulty">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="easy">Easy</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="hard">Hard</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="questionCount">Number of Questions</Label>
                  <Select 
                    value={formData.questionCount.toString()} 
                    onValueChange={(value) => setFormData(prev => ({ ...prev, questionCount: parseInt(value) }))}
                  >
                    <SelectTrigger data-testid="select-question-count">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="5">5 Questions</SelectItem>
                      <SelectItem value="10">10 Questions</SelectItem>
                      <SelectItem value="15">15 Questions</SelectItem>
                      <SelectItem value="20">20 Questions</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <Button 
                  onClick={handleGenerateQuiz}
                  disabled={isGenerating || !formData.topic.trim()}
                  className="w-full"
                  data-testid="button-generate-quiz"
                >
                  {isGenerating ? (
                    <>
                      <i className="fas fa-spinner fa-spin mr-2"></i>
                      Generating...
                    </>
                  ) : (
                    <>
                      <i className="fas fa-magic mr-2"></i>
                      Generate Quiz
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Previous Quizzes */}
          <div className="lg:col-span-2">
            <Card data-testid="previous-quizzes">
              <CardHeader>
                <CardTitle>Your Quizzes</CardTitle>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <div className="space-y-4">
                    {[...Array(3)].map((_, i) => (
                      <Skeleton key={i} className="h-24" />
                    ))}
                  </div>
                ) : quizzes?.length === 0 ? (
                  <div className="text-center py-8" data-testid="no-quizzes-message">
                    <i className="fas fa-question-circle text-4xl text-muted-foreground mb-4"></i>
                    <p className="text-muted-foreground">No quizzes yet. Generate your first AI quiz!</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {quizzes?.map((quiz: any) => (
                      <Card key={quiz.id} className="border-l-4 border-l-green-500" data-testid={`quiz-${quiz.id}`}>
                        <CardContent className="p-4">
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <h3 className="font-semibold text-foreground">{quiz.title}</h3>
                              <p className="text-sm text-muted-foreground mt-1">
                                Topic: {quiz.topic} • Difficulty: {quiz.difficulty}
                              </p>
                              <div className="flex items-center space-x-4 mt-2">
                                <Badge variant="outline">
                                  {quiz.questions?.length || 0} Questions
                                </Badge>
                                <span className="text-xs text-muted-foreground">
                                  Created {new Date(quiz.createdAt).toLocaleDateString()}
                                </span>
                              </div>
                            </div>
                            <Button 
                              variant="outline" 
                              size="sm"
                              onClick={() => setActiveQuiz(quiz)}
                            >
                              Take Quiz
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      ) : (
        /* Active Quiz View */
        <Card data-testid="active-quiz">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>{activeQuiz.title}</CardTitle>
                <p className="text-muted-foreground">
                  Topic: {activeQuiz.topic} • Difficulty: {activeQuiz.difficulty}
                </p>
              </div>
              <Button variant="outline" onClick={startNewQuiz}>
                <i className="fas fa-arrow-left mr-2"></i>
                Back to Generator
              </Button>
            </div>
          </CardHeader>
          <CardContent className="space-y-6">
            {activeQuiz.questions?.map((question: any, questionIndex: number) => (
              <div key={questionIndex} className="border rounded-lg p-4" data-testid={`question-${questionIndex}`}>
                <h3 className="font-medium text-foreground mb-4">
                  {questionIndex + 1}. {question.question}
                </h3>
                
                <RadioGroup
                  value={userAnswers[questionIndex]?.toString()}
                  onValueChange={(value) => handleAnswerChange(questionIndex, parseInt(value))}
                  disabled={showResults}
                >
                  {question.options?.map((option: string, optionIndex: number) => (
                    <div key={optionIndex} className="flex items-center space-x-2">
                      <RadioGroupItem 
                        value={optionIndex.toString()} 
                        id={`q${questionIndex}-option${optionIndex}`}
                        data-testid={`question-${questionIndex}-option-${optionIndex}`}
                      />
                      <Label 
                        htmlFor={`q${questionIndex}-option${optionIndex}`}
                        className={`flex-1 cursor-pointer ${
                          showResults && optionIndex === question.correctAnswer
                            ? 'text-green-600 font-medium'
                            : showResults && optionIndex === userAnswers[questionIndex] && optionIndex !== question.correctAnswer
                            ? 'text-red-600'
                            : ''
                        }`}
                      >
                        {option}
                      </Label>
                    </div>
                  ))}
                </RadioGroup>

                {showResults && (
                  <div className="mt-4 p-3 bg-muted rounded-lg">
                    <p className="text-sm text-muted-foreground">
                      <strong>Explanation:</strong> {question.explanation}
                    </p>
                  </div>
                )}
              </div>
            ))}

            {!showResults && (
              <div className="flex justify-center">
                <Button 
                  onClick={handleSubmitQuiz}
                  disabled={userAnswers.some(answer => answer === -1) || submitQuizMutation.isPending}
                  className="px-8"
                  data-testid="button-submit-quiz"
                >
                  {submitQuizMutation.isPending ? (
                    <>
                      <i className="fas fa-spinner fa-spin mr-2"></i>
                      Submitting...
                    </>
                  ) : (
                    <>
                      <i className="fas fa-check mr-2"></i>
                      Submit Quiz
                    </>
                  )}
                </Button>
              </div>
            )}

            {showResults && (
              <div className="text-center">
                <Button onClick={startNewQuiz} className="px-8">
                  <i className="fas fa-plus mr-2"></i>
                  Generate New Quiz
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
