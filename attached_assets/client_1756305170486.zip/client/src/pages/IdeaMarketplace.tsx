import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Skeleton } from '@/components/ui/skeleton';
import { useToast } from '@/hooks/use-toast';
import { api } from '@/lib/api';

export default function IdeaMarketplace() {
  const [isCreating, setIsCreating] = useState(false);
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    category: '',
    tags: ['']
  });

  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: ideas, isLoading } = useQuery({
    queryKey: ['/api/ideas'],
    queryFn: async () => {
      const response = await api.getIdeas();
      return response.json();
    },
  });

  const createIdeaMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await api.createIdea(data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/ideas'] });
      toast({ title: "Success", description: "Idea submitted successfully!" });
      setIsCreating(false);
      setFormData({ title: '', description: '', category: '', tags: [''] });
    },
    onError: (error) => {
      toast({ title: "Error", description: "Failed to submit idea" });
    },
  });

  const likeIdeaMutation = useMutation({
    mutationFn: async (ideaId: string) => {
      const response = await api.likeIdea(ideaId);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/ideas'] });
    },
  });

  const handleSubmitIdea = () => {
    const cleanedData = {
      ...formData,
      tags: formData.tags.filter(tag => tag.trim())
    };
    createIdeaMutation.mutate(cleanedData);
  };

  const addTag = () => {
    setFormData(prev => ({
      ...prev,
      tags: [...prev.tags, '']
    }));
  };

  const updateTag = (index: number, value: string) => {
    setFormData(prev => ({
      ...prev,
      tags: prev.tags.map((tag, i) => i === index ? value : tag)
    }));
  };

  const categories = [
    'Technology',
    'Education',
    'Healthcare',
    'Environment',
    'Social Impact',
    'Business',
    'Arts & Culture',
    'Science',
    'Other'
  ];

  return (
    <div className="space-y-6" data-testid="idea-marketplace">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Idea Marketplace</h1>
          <p className="text-muted-foreground">Discover and collaborate on innovative project ideas</p>
        </div>
        <Dialog open={isCreating} onOpenChange={setIsCreating}>
          <DialogTrigger asChild>
            <Button data-testid="button-submit-idea">
              <i className="fas fa-plus mr-2"></i>
              Submit New Idea
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[600px]" data-testid="idea-form-dialog">
            <DialogHeader>
              <DialogTitle>Submit New Idea</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="title">Title</Label>
                <Input
                  id="title"
                  placeholder="Enter a catchy title for your idea"
                  value={formData.title}
                  onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
                  data-testid="input-idea-title"
                />
              </div>

              <div>
                <Label htmlFor="category">Category</Label>
                <Select 
                  value={formData.category} 
                  onValueChange={(value) => setFormData(prev => ({ ...prev, category: value }))}
                >
                  <SelectTrigger data-testid="select-category">
                    <SelectValue placeholder="Select a category" />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map(category => (
                      <SelectItem key={category} value={category}>{category}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  placeholder="Describe your idea in detail..."
                  rows={4}
                  value={formData.description}
                  onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                  data-testid="textarea-description"
                />
              </div>

              <div>
                <Label>Tags</Label>
                {formData.tags.map((tag, index) => (
                  <div key={index} className="flex space-x-2 mt-2">
                    <Input
                      placeholder="Add a tag"
                      value={tag}
                      onChange={(e) => updateTag(index, e.target.value)}
                      data-testid={`input-tag-${index}`}
                    />
                  </div>
                ))}
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={addTag}
                  className="mt-2"
                  data-testid="button-add-tag"
                >
                  <i className="fas fa-plus mr-1"></i> Add Tag
                </Button>
              </div>

              <div className="flex justify-end space-x-2">
                <Button variant="outline" onClick={() => setIsCreating(false)}>
                  Cancel
                </Button>
                <Button 
                  onClick={handleSubmitIdea}
                  disabled={!formData.title.trim() || !formData.description.trim() || !formData.category || createIdeaMutation.isPending}
                  data-testid="button-submit-idea-form"
                >
                  {createIdeaMutation.isPending ? (
                    <>
                      <i className="fas fa-spinner fa-spin mr-2"></i>
                      Submitting...
                    </>
                  ) : (
                    <>
                      <i className="fas fa-paper-plane mr-2"></i>
                      Submit Idea
                    </>
                  )}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Ideas Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {isLoading ? (
          [...Array(6)].map((_, i) => (
            <Skeleton key={i} className="h-64" />
          ))
        ) : ideas?.length === 0 ? (
          <div className="col-span-full text-center py-12" data-testid="no-ideas-message">
            <i className="fas fa-lightbulb text-4xl text-muted-foreground mb-4"></i>
            <p className="text-muted-foreground">No ideas yet. Be the first to submit one!</p>
          </div>
        ) : (
          ideas?.map((idea: any) => (
            <Card key={idea.id} className="feature-card cursor-pointer" data-testid={`idea-${idea.id}`}>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <CardTitle className="text-lg">{idea.title}</CardTitle>
                    <div className="flex items-center space-x-2 mt-2">
                      <Badge variant="secondary">{idea.category}</Badge>
                      <Badge 
                        variant="outline" 
                        className={`${
                          idea.status === 'active' 
                            ? 'bg-green-100 text-green-700 border-green-200' 
                            : 'bg-blue-100 text-blue-700 border-blue-200'
                        }`}
                      >
                        {idea.status}
                      </Badge>
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground text-sm mb-4 line-clamp-3">
                  {idea.description}
                </p>

                {/* Tags */}
                {idea.tags && idea.tags.length > 0 && (
                  <div className="flex flex-wrap gap-1 mb-4">
                    {idea.tags.slice(0, 3).map((tag: string, index: number) => (
                      <Badge key={index} variant="outline" className="text-xs">
                        {tag}
                      </Badge>
                    ))}
                    {idea.tags.length > 3 && (
                      <Badge variant="outline" className="text-xs">
                        +{idea.tags.length - 3} more
                      </Badge>
                    )}
                  </div>
                )}

                {/* Collaborators */}
                {idea.collaborators && idea.collaborators.length > 0 && (
                  <div className="mb-4">
                    <p className="text-xs text-muted-foreground mb-2">
                      {idea.collaborators.length} collaborator(s)
                    </p>
                    <div className="flex -space-x-2">
                      {idea.collaborators.slice(0, 3).map((collaborator: any, index: number) => (
                        <img
                          key={index}
                          src={collaborator.avatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${collaborator.name}`}
                          alt={collaborator.name}
                          className="w-6 h-6 rounded-full border-2 border-white"
                        />
                      ))}
                      {idea.collaborators.length > 3 && (
                        <div className="w-6 h-6 rounded-full border-2 border-white bg-muted flex items-center justify-center text-xs">
                          +{idea.collaborators.length - 3}
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {/* Actions */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => likeIdeaMutation.mutate(idea.id)}
                      disabled={likeIdeaMutation.isPending}
                      data-testid={`button-like-${idea.id}`}
                    >
                      <i className="fas fa-heart mr-1 text-red-500"></i>
                      {idea.likes || 0}
                    </Button>
                    <span className="text-xs text-muted-foreground">
                      {new Date(idea.createdAt).toLocaleDateString()}
                    </span>
                  </div>
                  <Button size="sm" data-testid={`button-collaborate-${idea.id}`}>
                    <i className="fas fa-handshake mr-1"></i>
                    Collaborate
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}
