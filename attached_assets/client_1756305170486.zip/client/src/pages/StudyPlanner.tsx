import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { useToast } from '@/hooks/use-toast';
import { api } from '@/lib/api';

export default function StudyPlanner() {
  const [isGenerating, setIsGenerating] = useState(false);
  const [formData, setFormData] = useState({
    subjects: [''],
    availableHours: 10,
    goals: [''],
    preferences: ''
  });

  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: studyPlans, isLoading } = useQuery({
    queryKey: ['/api/study-plans'],
    queryFn: async () => {
      const response = await api.getStudyPlans();
      return response.json();
    },
  });

  const generatePlanMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await api.generateStudyPlan(data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/study-plans'] });
      toast({ title: "Success", description: "Study plan generated successfully!" });
      setIsGenerating(false);
    },
    onError: (error) => {
      toast({ title: "Error", description: "Failed to generate study plan" });
      setIsGenerating(false);
    },
  });

  const handleGeneratePlan = async () => {
    setIsGenerating(true);
    const cleanedData = {
      subjects: formData.subjects.filter(s => s.trim()),
      availableHours: formData.availableHours,
      goals: formData.goals.filter(g => g.trim()),
      preferences: formData.preferences
    };
    generatePlanMutation.mutate(cleanedData);
  };

  const addSubject = () => {
    setFormData(prev => ({
      ...prev,
      subjects: [...prev.subjects, '']
    }));
  };

  const updateSubject = (index: number, value: string) => {
    setFormData(prev => ({
      ...prev,
      subjects: prev.subjects.map((s, i) => i === index ? value : s)
    }));
  };

  const addGoal = () => {
    setFormData(prev => ({
      ...prev,
      goals: [...prev.goals, '']
    }));
  };

  const updateGoal = (index: number, value: string) => {
    setFormData(prev => ({
      ...prev,
      goals: prev.goals.map((g, i) => i === index ? value : g)
    }));
  };

  return (
    <div className="space-y-6" data-testid="study-planner">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">AI Study Planner</h1>
          <p className="text-muted-foreground">Generate personalized study schedules using AI</p>
        </div>
        <Badge variant="secondary" className="bg-accent text-accent-foreground">
          <i className="fas fa-robot mr-1"></i>
          Powered by Gemini
        </Badge>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Generation Form */}
        <div className="lg:col-span-1">
          <Card data-testid="plan-generator-form">
            <CardHeader>
              <CardTitle>Generate New Plan</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label>Subjects</Label>
                {formData.subjects.map((subject, index) => (
                  <div key={index} className="flex space-x-2 mt-2">
                    <Input
                      placeholder="Enter subject"
                      value={subject}
                      onChange={(e) => updateSubject(index, e.target.value)}
                      data-testid={`input-subject-${index}`}
                    />
                  </div>
                ))}
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={addSubject}
                  className="mt-2"
                  data-testid="button-add-subject"
                >
                  <i className="fas fa-plus mr-1"></i> Add Subject
                </Button>
              </div>

              <div>
                <Label htmlFor="hours">Available Hours per Week</Label>
                <Input
                  id="hours"
                  type="number"
                  min="1"
                  max="50"
                  value={formData.availableHours}
                  onChange={(e) => setFormData(prev => ({ ...prev, availableHours: parseInt(e.target.value) }))}
                  data-testid="input-hours"
                />
              </div>

              <div>
                <Label>Learning Goals</Label>
                {formData.goals.map((goal, index) => (
                  <div key={index} className="flex space-x-2 mt-2">
                    <Input
                      placeholder="Enter goal"
                      value={goal}
                      onChange={(e) => updateGoal(index, e.target.value)}
                      data-testid={`input-goal-${index}`}
                    />
                  </div>
                ))}
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={addGoal}
                  className="mt-2"
                  data-testid="button-add-goal"
                >
                  <i className="fas fa-plus mr-1"></i> Add Goal
                </Button>
              </div>

              <div>
                <Label htmlFor="preferences">Preferences (Optional)</Label>
                <Textarea
                  id="preferences"
                  placeholder="Morning sessions, breaks every hour, etc."
                  value={formData.preferences}
                  onChange={(e) => setFormData(prev => ({ ...prev, preferences: e.target.value }))}
                  data-testid="textarea-preferences"
                />
              </div>

              <Button 
                onClick={handleGeneratePlan}
                disabled={isGenerating || generatePlanMutation.isPending}
                className="w-full"
                data-testid="button-generate-plan"
              >
                {isGenerating || generatePlanMutation.isPending ? (
                  <>
                    <i className="fas fa-spinner fa-spin mr-2"></i>
                    Generating...
                  </>
                ) : (
                  <>
                    <i className="fas fa-magic mr-2"></i>
                    Generate AI Plan
                  </>
                )}
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Existing Plans */}
        <div className="lg:col-span-2">
          <Card data-testid="existing-plans">
            <CardHeader>
              <CardTitle>Your Study Plans</CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="space-y-4">
                  {[...Array(3)].map((_, i) => (
                    <Skeleton key={i} className="h-32" />
                  ))}
                </div>
              ) : studyPlans?.length === 0 ? (
                <div className="text-center py-8" data-testid="no-plans-message">
                  <i className="fas fa-calendar-plus text-4xl text-muted-foreground mb-4"></i>
                  <p className="text-muted-foreground">No study plans yet. Generate your first AI-powered plan!</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {studyPlans?.map((plan: any) => (
                    <Card key={plan.id} className="border-l-4 border-l-primary" data-testid={`plan-${plan.id}`}>
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <h3 className="font-semibold text-foreground">{plan.title}</h3>
                            <p className="text-sm text-muted-foreground mt-1">{plan.description}</p>
                            <div className="flex items-center space-x-4 mt-2">
                              <Badge variant="outline">
                                {plan.aiGenerated ? 'AI Generated' : 'Manual'}
                              </Badge>
                              <span className="text-xs text-muted-foreground">
                                Created {new Date(plan.createdAt).toLocaleDateString()}
                              </span>
                            </div>
                          </div>
                          <Button variant="outline" size="sm">
                            View Schedule
                          </Button>
                        </div>
                        
                        {/* Schedule Preview */}
                        {plan.schedule && (
                          <div className="mt-4 p-3 bg-muted rounded-lg">
                            <h4 className="text-sm font-medium mb-2">This Week's Schedule</h4>
                            <div className="grid grid-cols-7 gap-2 text-xs">
                              {Object.entries(plan.schedule).map(([day, activities]: [string, any]) => (
                                <div key={day} className="text-center">
                                  <div className="font-medium capitalize mb-1">{day.slice(0, 3)}</div>
                                  <div className="space-y-1">
                                    {activities?.slice(0, 2).map((activity: any, i: number) => (
                                      <div key={i} className="bg-background p-1 rounded text-xs">
                                        <div className="font-medium">{activity.time}</div>
                                        <div className="text-muted-foreground">{activity.subject}</div>
                                      </div>
                                    ))}
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
