import { Button } from '@/components/ui/button';
import { useAuth } from '@/hooks/useAuth';

export function AuthButton() {
  const { login, loading } = useAuth();

  return (
    <Button 
      onClick={login} 
      disabled={loading}
      className="flex items-center space-x-2"
      data-testid="login-button"
    >
      <i className="fab fa-google"></i>
      <span>{loading ? 'Signing in...' : 'Sign in with Google'}</span>
    </Button>
  );
}
