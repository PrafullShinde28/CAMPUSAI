// src/firebase.js
import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getAnalytics } from "firebase/analytics";

// Your Firebase config
const firebaseConfig = {
  apiKey: "AIzaSyB-AWNdM9VxYbZ0tIlp9EcTmt6fQPpcSrU",
  authDomain: "campusai-34339.firebaseapp.com",
  projectId: "campusai-34339",
  storageBucket: "campusai-34339.firebasestorage.app",
  messagingSenderId: "171327727521",
  appId: "1:171327727521:web:358fee974a817d406a0de0",
  measurementId: "G-1WC9TBMZP6"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);
export const auth = getAuth(app);
export default app;
