importScripts('https://www.gstatic.com/firebasejs/10.13.2/firebase-app-compat.js');
importScripts('https://www.gstatic.com/firebasejs/10.13.2/firebase-messaging-compat.js');

self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', (event) => event.waitUntil(self.clients.claim()));

firebase.initializeApp({
  apiKey: self.firebaseApiKey,
  authDomain: `${self.firebaseProjectId}.firebaseapp.com`,
  projectId: self.firebaseProjectId,
  storageBucket: `${self.firebaseProjectId}.firebasestorage.app`,
  appId: self.firebaseAppId,
  messagingSenderId: self.firebaseMessagingSenderId,
});

const messaging = firebase.messaging();

messaging.onBackgroundMessage((payload) => {
  const notificationTitle = payload.notification?.title || 'CampusAI';
  const notificationOptions = {
    body: payload.notification?.body || '',
    data: payload.data || {},
  };
  self.registration.showNotification(notificationTitle, notificationOptions);
});

