import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ 
  apiKey: process.env.GEMINI_API_KEY || process.env.GOOGLE_API_KEY || "" 
});

interface StudyPlanRequest {
  subjects: string[];
  availableHours: number;
  goals: string[];
  preferences?: any;
}

interface QuizRequest {
  topic: string;
  difficulty: string;
  questionCount: number;
}

interface QuizQuestion {
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
}

class GeminiService {
  async generateStudyPlan(request: StudyPlanRequest) {
    try {
      const prompt = `Create a personalized study plan with the following requirements:
      
Subjects: ${request.subjects.join(', ')}
Available hours per week: ${request.availableHours}
Goals: ${request.goals.join(', ')}

Generate a comprehensive study plan that includes:
1. A descriptive title
2. A brief description
3. A detailed weekly schedule with specific time slots, subjects, and activities

Respond with JSON in this exact format:
{
  "title": "string",
  "description": "string", 
  "schedule": {
    "monday": [{"time": "09:00-10:00", "subject": "Math", "activity": "Practice problems"}],
    "tuesday": [...],
    "wednesday": [...],
    "thursday": [...],
    "friday": [...],
    "saturday": [...],
    "sunday": [...]
  }
}`;

      const response = await ai.models.generateContent({
        model: "gemini-2.5-pro",
        config: {
          responseMimeType: "application/json",
        },
        contents: prompt,
      });

      const rawJson = response.text;
      if (rawJson) {
        return JSON.parse(rawJson);
      } else {
        throw new Error("Empty response from AI model");
      }
    } catch (error) {
      console.error('Error generating study plan:', error);
      throw new Error(`Failed to generate study plan: ${error.message}`);
    }
  }

  async generateQuiz(request: QuizRequest) {
    try {
      const prompt = `Create a ${request.difficulty} difficulty quiz about "${request.topic}" with ${request.questionCount} multiple choice questions.

Each question should have:
- A clear question
- 4 multiple choice options
- The correct answer index (0-3)
- A brief explanation of why the answer is correct

Respond with JSON in this exact format:
{
  "title": "Quiz Title",
  "questions": [
    {
      "question": "Question text?",
      "options": ["Option A", "Option B", "Option C", "Option D"],
      "correctAnswer": 0,
      "explanation": "Explanation text"
    }
  ]
}`;

      const response = await ai.models.generateContent({
        model: "gemini-2.5-pro",
        config: {
          responseMimeType: "application/json",
        },
        contents: prompt,
      });

      const rawJson = response.text;
      if (rawJson) {
        return JSON.parse(rawJson);
      } else {
        throw new Error("Empty response from AI model");
      }
    } catch (error) {
      console.error('Error generating quiz:', error);
      throw new Error(`Failed to generate quiz: ${error.message}`);
    }
  }

  async explainText(text: string, context?: string) {
    try {
      const prompt = `Please explain the following text in a clear, educational way:

Text to explain: "${text}"
${context ? `Context: ${context}` : ''}

Provide:
1. A simple explanation
2. Key concepts involved
3. Real-world examples if applicable
4. Related topics the user might want to explore

Keep the explanation concise but comprehensive.`;

      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: prompt,
      });

      return response.text || "Unable to generate explanation";
    } catch (error) {
      console.error('Error explaining text:', error);
      throw new Error(`Failed to explain text: ${error.message}`);
    }
  }

  calculateQuizScore(questions: QuizQuestion[], answers: number[]): number {
    let correct = 0;
    questions.forEach((question, index) => {
      if (answers[index] === question.correctAnswer) {
        correct++;
      }
    });
    return Math.round((correct / questions.length) * 100);
  }

  async findPeerMatches(userId: string, subjects: string[], preferences: any) {
    // In a real implementation, this would query the database for users with similar interests
    // For now, return mock data structure that the frontend expects
    return [
      {
        id: "peer1",
        name: "Sarah Chen",
        subjects: ["Mathematics", "Physics"],
        compatibility: 94,
        avatar: "https://pixabay.com/get/gabd5fdee31f4a075a5d0790607d1745d6cc913f10d2c9aed4c26c8d1f2444f0414c717baab5bb13ab571e7efd875f33cdc0984811594b29f308976a0ead56e0b_1280.jpg"
      },
      {
        id: "peer2", 
        name: "Marcus Johnson",
        subjects: ["Physics", "Chemistry"],
        compatibility: 89,
        avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100"
      }
    ];
  }
}

export const geminiService = new GeminiService();
