import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { geminiService } from "./services/gemini";
import { insertStudyPlanSchema, insertQuizSchema, insertIdeaSchema, insertStudySessionSchema, insertQuizAttemptSchema } from "@shared/schema";
import { authMiddleware } from "./middleware/auth";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth routes
  app.get("/api/auth/user", async (req, res) => {
    try {
      const userId = req.headers["x-user-id"] as string;
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      res.json(user);
    } catch (error) {
      res.status(500).json({ message: "Failed to get user", error: error.message });
    }
  });

  app.post("/api/auth/google", async (req, res) => {
    try {
      const { email, name, avatar, googleId } = req.body;
      
      let user = await storage.getUserByGoogleId(googleId);
      if (!user) {
        user = await storage.getUserByEmail(email);
        if (!user) {
          user = await storage.createUser({ email, name, avatar, googleId });
        } else {
          user = await storage.updateUser(user.id, { googleId, avatar, name });
        }
      }

      res.json(user);
    } catch (error) {
      res.status(500).json({ message: "Authentication failed", error: error.message });
    }
  });

  // Secure API routes with Firebase auth
  app.use("/api/study-plans", authMiddleware);
  app.use("/api/quizzes", authMiddleware);
  app.use("/api/study-sessions", authMiddleware);
  app.use("/api/peer-matches", authMiddleware);
  app.use("/api/dashboard", authMiddleware);

  // Study Plan routes
  app.get("/api/study-plans", async (req, res) => {
    try {
      const userId = req.headers["x-user-id"] as string;
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const plans = await storage.getStudyPlans(userId);
      res.json(plans);
    } catch (error) {
      res.status(500).json({ message: "Failed to get study plans", error: error.message });
    }
  });

  app.post("/api/study-plans", async (req, res) => {
    try {
      const userId = req.headers["x-user-id"] as string;
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const planData = insertStudyPlanSchema.parse({ ...req.body, userId });
      const plan = await storage.createStudyPlan(planData);
      res.json(plan);
    } catch (error) {
      res.status(500).json({ message: "Failed to create study plan", error: error.message });
    }
  });

  app.post("/api/study-plans/generate", async (req, res) => {
    try {
      const userId = req.headers["x-user-id"] as string;
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const { subjects, availableHours, goals, preferences } = req.body;
      
      const aiPlan = await geminiService.generateStudyPlan({
        subjects,
        availableHours,
        goals,
        preferences
      });

      const plan = await storage.createStudyPlan({
        userId,
        title: aiPlan.title,
        description: aiPlan.description,
        schedule: aiPlan.schedule,
        aiGenerated: true
      });

      res.json(plan);
    } catch (error) {
      res.status(500).json({ message: "Failed to generate study plan", error: error.message });
    }
  });

  // Alias: /api/planner
  app.post("/api/planner", authMiddleware, async (req, res) => {
    try {
      const userId = req.headers["x-user-id"] as string;
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const { subjects, availableHours, goals, preferences } = req.body;
      const aiPlan = await geminiService.generateStudyPlan({ subjects, availableHours, goals, preferences });
      res.json(aiPlan);
    } catch (error) {
      res.status(500).json({ message: "Failed to generate plan", error: (error as any).message });
    }
  });

  // Quiz routes
  app.get("/api/quizzes", async (req, res) => {
    try {
      const userId = req.headers["x-user-id"] as string;
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const quizzes = await storage.getQuizzes(userId);
      res.json(quizzes);
    } catch (error) {
      res.status(500).json({ message: "Failed to get quizzes", error: error.message });
    }
  });

  app.post("/api/quizzes/generate", async (req, res) => {
    try {
      const userId = req.headers["x-user-id"] as string;
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const { topic, difficulty, questionCount } = req.body;
      
      const aiQuiz = await geminiService.generateQuiz({
        topic,
        difficulty,
        questionCount
      });

      const quiz = await storage.createQuiz({
        userId,
        title: aiQuiz.title,
        topic,
        questions: aiQuiz.questions,
        difficulty,
        aiGenerated: true
      });

      res.json(quiz);
    } catch (error) {
      res.status(500).json({ message: "Failed to generate quiz", error: error.message });
    }
  });

  // Alias: /api/quiz
  app.post("/api/quiz", authMiddleware, async (req, res) => {
    try {
      const userId = req.headers["x-user-id"] as string;
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const { topic, difficulty, questionCount } = req.body;
      const aiQuiz = await geminiService.generateQuiz({ topic, difficulty, questionCount });
      res.json(aiQuiz);
    } catch (error) {
      res.status(500).json({ message: "Failed to generate quiz", error: (error as any).message });
    }
  });

  app.post("/api/quizzes/:id/attempt", async (req, res) => {
    try {
      const userId = req.headers["x-user-id"] as string;
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const quizId = req.params.id;
      const { answers } = req.body;

      const quiz = await storage.getQuiz(quizId);
      if (!quiz) {
        return res.status(404).json({ message: "Quiz not found" });
      }

      const score = geminiService.calculateQuizScore(quiz.questions as any[], answers);

      const attempt = await storage.createQuizAttempt({
        quizId,
        userId,
        answers,
        score
      });

      res.json(attempt);
    } catch (error) {
      res.status(500).json({ message: "Failed to submit quiz attempt", error: error.message });
    }
  });

  // Learning Buddy routes
  app.post("/api/learning-buddy/explain", async (req, res) => {
    try {
      const { text, context } = req.body;
      
      const explanation = await geminiService.explainText(text, context);
      res.json({ explanation });
    } catch (error) {
      res.status(500).json({ message: "Failed to explain text", error: error.message });
    }
  });

  // Placeholder: Google Classroom-driven planner endpoint
  app.post("/api/planner/classroom", authMiddleware, async (req, res) => {
    try {
      // In a production app, exchange Firebase user OAuth credential for Google access token
      // and call Classroom API to fetch coursework. Here we return mock structure.
      const { courses } = req.body as { courses?: string[] };
      const subjects = courses && courses.length ? courses : ["Math", "Science", "History"];
      const aiPlan = await geminiService.generateStudyPlan({
        subjects,
        availableHours: 10,
        goals: ["Complete assignments", "Prepare for quizzes"],
      });
      res.json({ source: "classroom", ...aiPlan });
    } catch (error) {
      res.status(500).json({ message: "Failed to plan from Classroom", error: (error as any).message });
    }
  });

  // Aliases requested by spec
  app.post("/api/docs/explain", async (req, res) => {
    try {
      const { text, context } = req.body;
      const explanation = await geminiService.explainText(text, context);
      res.json({ explanation });
    } catch (error) {
      res.status(500).json({ message: "Failed to explain text", error: error.message });
    }
  });

  // Ideas routes
  app.get("/api/ideas", async (req, res) => {
    try {
      const ideas = await storage.getIdeas();
      res.json(ideas);
    } catch (error) {
      res.status(500).json({ message: "Failed to get ideas", error: error.message });
    }
  });

  app.post("/api/ideas", async (req, res) => {
    try {
      const userId = req.headers["x-user-id"] as string;
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const ideaData = insertIdeaSchema.parse({ ...req.body, userId });
      const idea = await storage.createIdea(ideaData);
      res.json(idea);
    } catch (error) {
      res.status(500).json({ message: "Failed to create idea", error: error.message });
    }
  });

  // Firebase Cloud Messaging endpoints (store tokens, trigger test notifications)
  app.post("/api/notifications/token", authMiddleware, async (req, res) => {
    try {
      const userId = req.headers["x-user-id"] as string;
      const { fcmToken } = req.body as { fcmToken: string };
      if (!fcmToken) return res.status(400).json({ message: "Missing fcmToken" });
      // Persist fcmToken to user.preferences for demo purposes
      const user = await storage.getUser(userId);
      if (user) {
        const prefs = (user.preferences as any) || {};
        prefs.fcmToken = fcmToken;
        await storage.updateUser(userId, { preferences: prefs as any });
      }
      res.json({ ok: true });
    } catch (error) {
      res.status(500).json({ message: "Failed to save FCM token", error: (error as any).message });
    }
  });

  app.post("/api/notifications/test", authMiddleware, async (req, res) => {
    try {
      const userId = req.headers["x-user-id"] as string;
      const user = await storage.getUser(userId);
      const token = (user?.preferences as any)?.fcmToken as string | undefined;
      if (!token) return res.status(400).json({ message: "No FCM token registered" });
      const { firebaseService } = await import('./services/firebase');
      await firebaseService.sendNotification(userId, 'CampusAI Test', 'Notifications are working!', { fcmToken: token });
      res.json({ sent: true });
    } catch (error) {
      res.status(500).json({ message: "Failed to send test notification", error: (error as any).message });
    }
  });

  app.post("/api/ideas/:id/like", async (req, res) => {
    try {
      const ideaId = req.params.id;
      const idea = await storage.getIdea(ideaId);
      
      if (!idea) {
        return res.status(404).json({ message: "Idea not found" });
      }

      const updatedIdea = await storage.updateIdea(ideaId, { 
        likes: (idea.likes || 0) + 1 
      });
      
      res.json(updatedIdea);
    } catch (error) {
      res.status(500).json({ message: "Failed to like idea", error: error.message });
    }
  });

  // Study Sessions routes
  app.get("/api/study-sessions", async (req, res) => {
    try {
      const userId = req.headers["x-user-id"] as string;
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const sessions = await storage.getStudySessions(userId);
      res.json(sessions);
    } catch (error) {
      res.status(500).json({ message: "Failed to get study sessions", error: error.message });
    }
  });

  app.post("/api/study-sessions", async (req, res) => {
    try {
      const userId = req.headers["x-user-id"] as string;
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const sessionData = insertStudySessionSchema.parse({ ...req.body, userId });
      const session = await storage.createStudySession(sessionData);
      
      // Update user study hours
      const user = await storage.getUser(userId);
      if (user) {
        await storage.updateUser(userId, {
          totalStudyHours: (user.totalStudyHours || 0) + Math.round(sessionData.duration / 60)
        });
      }

      res.json(session);
    } catch (error) {
      res.status(500).json({ message: "Failed to create study session", error: error.message });
    }
  });

  // Peer Matchmaker routes
  app.get("/api/peer-matches", async (req, res) => {
    try {
      const userId = req.headers["x-user-id"] as string;
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const matches = await storage.getPeerMatches(userId);
      res.json(matches);
    } catch (error) {
      res.status(500).json({ message: "Failed to get peer matches", error: error.message });
    }
  });

  app.post("/api/peer-matches/find", async (req, res) => {
    try {
      const userId = req.headers["x-user-id"] as string;
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const { subjects, preferences } = req.body;
      
      // Simple matching logic - in production, this would use more sophisticated algorithms
      const potentialMatches = await geminiService.findPeerMatches(userId, subjects, preferences);
      
      res.json(potentialMatches);
    } catch (error) {
      res.status(500).json({ message: "Failed to find peer matches", error: error.message });
    }
  });

  // Alias: /api/matchmaker
  app.post("/api/matchmaker", authMiddleware, async (req, res) => {
    try {
      const userId = req.headers["x-user-id"] as string;
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      const { subjects, preferences } = req.body;
      const potentialMatches = await geminiService.findPeerMatches(userId, subjects, preferences);
      res.json(potentialMatches);
    } catch (error) {
      res.status(500).json({ message: "Failed to find peer matches", error: (error as any).message });
    }
  });

  // Dashboard stats
  app.get("/api/dashboard/stats", async (req, res) => {
    try {
      const userId = req.headers["x-user-id"] as string;
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const user = await storage.getUser(userId);
      const sessions = await storage.getStudySessions(userId);
      const quizAttempts = await storage.getQuizAttempts(userId);
      const ideas = await storage.getUserIdeas(userId);

      const thisWeekSessions = sessions.filter(s => 
        new Date(s.createdAt!) > new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)
      );

      const thisWeekHours = thisWeekSessions.reduce((total, session) => 
        total + (session.duration / 60), 0
      );

      const avgScore = quizAttempts.length > 0 
        ? quizAttempts.reduce((sum, attempt) => sum + attempt.score, 0) / quizAttempts.length
        : 0;

      res.json({
        studyStreak: user?.studyStreak || 0,
        avgQuizScore: Math.round(avgScore),
        weeklyStudyHours: Math.round(thisWeekHours * 10) / 10,
        activeProjects: ideas.filter(i => i.status === 'active').length
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to get dashboard stats", error: error.message });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
