import { 
  users, studyPlans, quizzes, quizAttempts, ideas, studySessions, peerMatches,
  type User, type InsertUser, type StudyPlan, type InsertStudyPlan,
  type Quiz, type InsertQuiz, type QuizAttempt, type InsertQuizAttempt,
  type Idea, type InsertIdea, type StudySession, type InsertStudySession,
  type PeerMatch
} from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";

interface IStorage {
  // User methods
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getUserByGoogleId(googleId: string): Promise<User | undefined>;
  createUser(insertUser: InsertUser): Promise<User>;
  updateUser(id: string, updates: Partial<InsertUser>): Promise<User>;

  // Study Plan methods
  getStudyPlans(userId: string): Promise<StudyPlan[]>;
  createStudyPlan(insertStudyPlan: InsertStudyPlan): Promise<StudyPlan>;

  // Quiz methods
  getQuizzes(userId: string): Promise<Quiz[]>;
  getQuiz(id: string): Promise<Quiz | undefined>;
  createQuiz(insertQuiz: InsertQuiz): Promise<Quiz>;
  getQuizAttempts(userId: string): Promise<QuizAttempt[]>;
  createQuizAttempt(insertQuizAttempt: InsertQuizAttempt): Promise<QuizAttempt>;

  // Idea methods
  getIdeas(): Promise<Idea[]>;
  getUserIdeas(userId: string): Promise<Idea[]>;
  getIdea(id: string): Promise<Idea | undefined>;
  createIdea(insertIdea: InsertIdea): Promise<Idea>;
  updateIdea(id: string, updates: Partial<InsertIdea>): Promise<Idea>;

  // Study Session methods
  getStudySessions(userId: string): Promise<StudySession[]>;
  createStudySession(insertStudySession: InsertStudySession): Promise<StudySession>;

  // Peer Match methods
  getPeerMatches(userId: string): Promise<PeerMatch[]>;
}

export class DatabaseStorage implements IStorage {
  // User methods
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async getUserByGoogleId(googleId: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.googleId, googleId));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async updateUser(id: string, updates: Partial<InsertUser>): Promise<User> {
    const [user] = await db
      .update(users)
      .set(updates)
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  // Study Plan methods
  async getStudyPlans(userId: string): Promise<StudyPlan[]> {
    return await db.select().from(studyPlans).where(eq(studyPlans.userId, userId));
  }

  async createStudyPlan(insertStudyPlan: InsertStudyPlan): Promise<StudyPlan> {
    const [plan] = await db
      .insert(studyPlans)
      .values(insertStudyPlan)
      .returning();
    return plan;
  }

  // Quiz methods
  async getQuizzes(userId: string): Promise<Quiz[]> {
    return await db.select().from(quizzes).where(eq(quizzes.userId, userId));
  }

  async getQuiz(id: string): Promise<Quiz | undefined> {
    const [quiz] = await db.select().from(quizzes).where(eq(quizzes.id, id));
    return quiz || undefined;
  }

  async createQuiz(insertQuiz: InsertQuiz): Promise<Quiz> {
    const [quiz] = await db
      .insert(quizzes)
      .values(insertQuiz)
      .returning();
    return quiz;
  }

  async getQuizAttempts(userId: string): Promise<QuizAttempt[]> {
    return await db.select().from(quizAttempts).where(eq(quizAttempts.userId, userId));
  }

  async createQuizAttempt(insertQuizAttempt: InsertQuizAttempt): Promise<QuizAttempt> {
    const [attempt] = await db
      .insert(quizAttempts)
      .values(insertQuizAttempt)
      .returning();
    return attempt;
  }

  // Idea methods
  async getIdeas(): Promise<Idea[]> {
    return await db.select().from(ideas);
  }

  async getUserIdeas(userId: string): Promise<Idea[]> {
    return await db.select().from(ideas).where(eq(ideas.userId, userId));
  }

  async getIdea(id: string): Promise<Idea | undefined> {
    const [idea] = await db.select().from(ideas).where(eq(ideas.id, id));
    return idea || undefined;
  }

  async createIdea(insertIdea: InsertIdea): Promise<Idea> {
    const [idea] = await db
      .insert(ideas)
      .values(insertIdea)
      .returning();
    return idea;
  }

  async updateIdea(id: string, updates: Partial<InsertIdea>): Promise<Idea> {
    const [idea] = await db
      .update(ideas)
      .set(updates)
      .where(eq(ideas.id, id))
      .returning();
    return idea;
  }

  // Study Session methods
  async getStudySessions(userId: string): Promise<StudySession[]> {
    return await db.select().from(studySessions).where(eq(studySessions.userId, userId));
  }

  async createStudySession(insertStudySession: InsertStudySession): Promise<StudySession> {
    const [session] = await db
      .insert(studySessions)
      .values(insertStudySession)
      .returning();
    return session;
  }

  // Peer Match methods
  async getPeerMatches(userId: string): Promise<PeerMatch[]> {
    return await db.select().from(peerMatches).where(eq(peerMatches.userId1, userId));
  }
}

export const storage = new DatabaseStorage();