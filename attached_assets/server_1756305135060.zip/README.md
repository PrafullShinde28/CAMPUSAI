# CampusAI

## Setup

Create a .env file in the project root (server reads it; client uses VITE_* via import.meta.env):

```
GEMINI_API_KEY=your_google_genai_key

# Firebase (client)
VITE_FIREBASE_API_KEY=...
VITE_FIREBASE_PROJECT_ID=...
VITE_FIREBASE_APP_ID=...
VITE_FIREBASE_MESSAGING_SENDER_ID=...
VITE_FIREBASE_VAPID_KEY=your_web_push_vapid_key

# Firebase (server)
FIREBASE_PROJECT_ID=...
# Provide ADC or inline service account JSON
# FIREBASE_SERVICE_ACCOUNT_JSON={"type":"service_account",...}
```

## Run

```
npm run dev
```

## Notes

- Google Sign-In uses Firebase Auth (redirect). Client sends Authorization: Bearer <idToken> on API calls.
- FCM: service worker at `client/public/firebase-messaging-sw.js`. After login, token is saved via `/api/notifications/token`. Test with `POST /api/notifications/test`.
- Aliases: `/api/planner`, `/api/quiz`, `/api/matchmaker`, `/api/docs/explain`. Classroom placeholder: `/api/planner/classroom`.