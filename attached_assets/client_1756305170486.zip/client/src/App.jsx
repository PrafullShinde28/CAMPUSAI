import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider } from "@/hooks/useAuth";
import { Layout } from "@/components/Layout";
import NotFound from "@/pages/not-found";
import Home from "@/pages/Home";
import StudyPlanner from "@/pages/StudyPlanner";
import QuizGenerator from "@/pages/QuizGenerator";
import LearningBuddy from "@/pages/LearningBuddy";
import IdeaMarketplace from "@/pages/IdeaMarketplace";
import PeerMatchmaker from "@/pages/PeerMatchmaker";

function Router() {
  return (
    <Layout>
      <Switch>
        <Route path="/" component={Home} />
        <Route path="/study-planner" component={StudyPlanner} />
        <Route path="/quiz-generator" component={QuizGenerator} />
        <Route path="/learning-buddy" component={LearningBuddy} />
        <Route path="/idea-marketplace" component={IdeaMarketplace} />
        <Route path="/peer-matchmaker" component={PeerMatchmaker} />
        <Route component={NotFound} />
      </Switch>
    </Layout>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
