import admin from 'firebase-admin';

// Initialize Firebase Admin SDK
if (!admin.apps.length) {
  const hasServiceAccount = !!process.env.FIREBASE_SERVICE_ACCOUNT_JSON;
  const credential = hasServiceAccount
    ? admin.credential.cert(JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT_JSON!))
    : admin.credential.applicationDefault();

  admin.initializeApp({
    credential,
    projectId: process.env.FIREBASE_PROJECT_ID,
  });
}

export class FirebaseService {
  async sendNotification(userId: string, title: string, body: string, data?: any) {
    try {
      // In a real implementation, get the user's FCM token from DB
      // This demo expects you stored it in user.preferences.fcmToken via /api/notifications/token
      const token = data?.fcmToken as string | undefined;
      if (!token) {
        console.log(`Skipping send; missing FCM token for ${userId}`);
        return;
      }

      const message = {
        notification: { title, body },
        data: data || {},
        token,
      } as admin.messaging.Message;

      const response = await admin.messaging().send(message);
      return response;
    } catch (error) {
      console.error('Error sending notification:', error);
      throw error;
    }
  }

  async verifyIdToken(idToken: string) {
    try {
      const decodedToken = await admin.auth().verifyIdToken(idToken);
      return decodedToken;
    } catch (error) {
      console.error('Error verifying token:', error);
      throw error;
    }
  }
}

export const firebaseService = new FirebaseService();
