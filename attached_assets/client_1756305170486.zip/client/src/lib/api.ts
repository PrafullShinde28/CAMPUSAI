import { apiRequest } from './queryClient';
import { useAuth } from '@/hooks/useAuth';

// Enhanced API client with authentication headers
export async function authenticatedRequest(
  method: string,
  url: string,
  data?: unknown
): Promise<Response> {
  const headers: Record<string, string> = {};

  // Include Firebase ID token if available
  try {
    const { auth } = await import("@/config/firebase");
    const currentUser = auth.currentUser;
    if (currentUser) {
      const token = await currentUser.getIdToken();
      headers["Authorization"] = `Bearer ${token}`;
    }
  } catch {}

  const response = await fetch(url, {
    method,
    headers: {
      'Content-Type': 'application/json',
      ...headers,
    },
    body: data ? JSON.stringify(data) : undefined,
    credentials: 'include',
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`${response.status}: ${errorText}`);
  }

  return response;
}

// API functions
export const api = {
  // Auth
  getCurrentUser: () => authenticatedRequest('GET', '/api/auth/user'),
  
  // Dashboard
  getDashboardStats: () => authenticatedRequest('GET', '/api/dashboard/stats'),
  
  // Study Plans
  getStudyPlans: () => authenticatedRequest('GET', '/api/study-plans'),
  createStudyPlan: (data: any) => authenticatedRequest('POST', '/api/study-plans', data),
  generateStudyPlan: (data: any) => authenticatedRequest('POST', '/api/study-plans/generate', data),
  
  // Quizzes
  getQuizzes: () => authenticatedRequest('GET', '/api/quizzes'),
  generateQuiz: (data: any) => authenticatedRequest('POST', '/api/quizzes/generate', data),
  submitQuizAttempt: (quizId: string, data: any) => 
    authenticatedRequest('POST', `/api/quizzes/${quizId}/attempt`, data),
  
  // Learning Buddy
  explainText: (data: any) => authenticatedRequest('POST', '/api/learning-buddy/explain', data),
  
  // Ideas
  getIdeas: () => authenticatedRequest('GET', '/api/ideas'),
  createIdea: (data: any) => authenticatedRequest('POST', '/api/ideas', data),
  likeIdea: (ideaId: string) => authenticatedRequest('POST', `/api/ideas/${ideaId}/like`),
  
  // Study Sessions
  getStudySessions: () => authenticatedRequest('GET', '/api/study-sessions'),
  createStudySession: (data: any) => authenticatedRequest('POST', '/api/study-sessions', data),
  
  // Peer Matches
  getPeerMatches: () => authenticatedRequest('GET', '/api/peer-matches'),
  findPeerMatches: (data: any) => authenticatedRequest('POST', '/api/peer-matches/find', data),
};
