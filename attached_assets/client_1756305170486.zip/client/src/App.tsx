import { BrowserRouter, Routes, Route, Navigate, useNavigate } from "react-router-dom";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider } from "@/hooks/useAuth";
import { Layout } from "@/components/Layout";
import NotFound from "@/pages/not-found";
import Home from "@/pages/Home";
import Login from "@/pages/Login";
import StudyPlanner from "@/pages/StudyPlanner";
import QuizGenerator from "@/pages/QuizGenerator";
import LearningBuddy from "@/pages/LearningBuddy";
import IdeaMarketplace from "@/pages/IdeaMarketplace";
import PeerMatchmaker from "@/pages/PeerMatchmaker";
import { useEffect } from "react";
import { auth } from "./firebase";
import { onAuthStateChanged, signInWithEmailAndPassword } from "firebase/auth";

// ---------------------- Router Component ----------------------
function Router() {
  return (
    <Layout>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/study-planner" element={<StudyPlanner />} />
        <Route path="/quiz-generator" element={<QuizGenerator />} />
        <Route path="/learning-buddy" element={<LearningBuddy />} />
        <Route path="/idea-marketplace" element={<IdeaMarketplace />} />
        <Route path="/peer-matchmaker" element={<PeerMatchmaker />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
    </Layout>
  );
}

// ---------------------- App Component ----------------------
function App() {
  const navigate = useNavigate();

  // Redirect on auth state change
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      if (user) {
        navigate("/"); // go to Home or dashboard
      } else {
        navigate("/login");
      }
    });

    return () => unsubscribe();
  }, [navigate]);

  // Example: Manual login handler
  const handleSignIn = (email: string, password: string) => {
    signInWithEmailAndPassword(auth, email, password)
      .then(() => navigate("/")) // after login go to home
      .catch((error) => console.error("Login failed", error));
  };

  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <TooltipProvider>
          <Toaster />
          <BrowserRouter>
            <Router />
          </BrowserRouter>
        </TooltipProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
