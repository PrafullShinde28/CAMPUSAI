import { getMessaging, getToken, onMessage, isSupported } from "firebase/messaging";
import { initializeApp } from "firebase/app";

let messagingInitialized = false;

export async function initMessaging(): Promise<void> {
  if (messagingInitialized) return;
  if (!(await isSupported())) return;

  const app = initializeApp({
    apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
    authDomain: `${import.meta.env.VITE_FIREBASE_PROJECT_ID}.firebaseapp.com`,
    projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
    storageBucket: `${import.meta.env.VITE_FIREBASE_PROJECT_ID}.firebasestorage.app`,
    appId: import.meta.env.VITE_FIREBASE_APP_ID,
    messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID,
  }, "messaging");

  const messaging = getMessaging(app);
  const vapidKey = import.meta.env.VITE_FIREBASE_VAPID_KEY;
  const token = await getToken(messaging, { vapidKey });
  if (token) {
    await fetch('/api/notifications/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ fcmToken: token })
    });
  }

  onMessage(messaging, (payload) => {
    console.debug('Foreground message received', payload);
  });

  messagingInitialized = true;
}

