import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Skeleton } from '@/components/ui/skeleton';
import { useToast } from '@/hooks/use-toast';
import { api } from '@/lib/api';

export default function PeerMatchmaker() {
  const [isUpdatingPreferences, setIsUpdatingPreferences] = useState(false);
  const [preferences, setPreferences] = useState({
    subjects: [],
    studyStyle: '',
    availability: '',
    goals: '',
    location: ''
  });

  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: matches, isLoading: matchesLoading } = useQuery({
    queryKey: ['/api/peer-matches'],
    queryFn: async () => {
      const response = await api.getPeerMatches();
      return response.json();
    },
  });

  const findMatchesMutation = useMutation({
    mutationFn: async (data) => {
      const response = await api.findPeerMatches(data);
      return response.json();
    },
    onSuccess: (newMatches) => {
      queryClient.invalidateQueries({ queryKey: ['/api/peer-matches'] });
      toast({ 
        title: "Success", 
        description: `Found ${newMatches.length} potential matches!` 
      });
    },
    onError: (error) => {
      toast({ title: "Error", description: "Failed to find peer matches" });
    },
  });

  const handleFindMatches = () => {
    const cleanedPreferences = {
      subjects: preferences.subjects,
      studyStyle: preferences.studyStyle,
      availability: preferences.availability,
      goals: preferences.goals,
      location: preferences.location
    };
    findMatchesMutation.mutate(cleanedPreferences);
  };

  const handleSubjectChange = (subject, checked) => {
    setPreferences(prev => ({
      ...prev,
      subjects: checked 
        ? [...prev.subjects, subject]
        : prev.subjects.filter(s => s !== subject)
    }));
  };

  const subjects = [
    'Mathematics',
    'Physics', 
    'Chemistry',
    'Biology',
    'Computer Science',
    'Engineering',
    'Literature',
    'History',
    'Psychology',
    'Economics',
    'Business',
    'Art & Design'
  ];

  const studyStyles = [
    'Visual Learner',
    'Auditory Learner', 
    'Kinesthetic Learner',
    'Reading/Writing Learner',
    'Group Study',
    'Individual Study',
    'Discussion-based',
    'Practice-based'
  ];

  // Get potential matches from API
  const { data: potentialMatches } = useQuery({
    queryKey: ['/api/peer-matches/find', preferences],
    queryFn: async () => {
      if (preferences.subjects.length === 0) return [];
      const response = await api.findPeerMatches(preferences);
      return response.json();
    },
    enabled: preferences.subjects.length > 0,
  });

  return (
    <div className="space-y-6" data-testid="peer-matchmaker">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Peer Matchmaker</h1>
          <p className="text-muted-foreground">Find study partners and collaborators based on your preferences</p>
        </div>
        <Dialog open={isUpdatingPreferences} onOpenChange={setIsUpdatingPreferences}>
          <DialogTrigger asChild>
            <Button data-testid="button-update-preferences">
              <i className="fas fa-cog mr-2"></i>
              Update Preferences
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[600px]" data-testid="preferences-dialog">
            <DialogHeader>
              <DialogTitle>Update Study Preferences</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 max-h-96 overflow-y-auto">
              <div>
                <Label>Subjects of Interest</Label>
                <div className="grid grid-cols-2 gap-2 mt-2">
                  {subjects.map(subject => (
                    <div key={subject} className="flex items-center space-x-2">
                      <Checkbox
                        id={subject}
                        checked={preferences.subjects.includes(subject)}
                        onCheckedChange={(checked) => handleSubjectChange(subject, checked)}
                        data-testid={`checkbox-${subject.toLowerCase().replace(' ', '-')}`}
                      />
                      <Label htmlFor={subject} className="text-sm">{subject}</Label>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <Label htmlFor="studyStyle">Preferred Study Style</Label>
                <Select 
                  value={preferences.studyStyle} 
                  onValueChange={(value) => setPreferences(prev => ({ ...prev, studyStyle: value }))}
                >
                  <SelectTrigger data-testid="select-study-style">
                    <SelectValue placeholder="Select your study style" />
                  </SelectTrigger>
                  <SelectContent>
                    {studyStyles.map(style => (
                      <SelectItem key={style} value={style}>{style}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="availability">Availability</Label>
                <Select 
                  value={preferences.availability} 
                  onValueChange={(value) => setPreferences(prev => ({ ...prev, availability: value }))}
                >
                  <SelectTrigger data-testid="select-availability">
                    <SelectValue placeholder="When are you available to study?" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="mornings">Mornings</SelectItem>
                    <SelectItem value="afternoons">Afternoons</SelectItem>
                    <SelectItem value="evenings">Evenings</SelectItem>
                    <SelectItem value="weekends">Weekends</SelectItem>
                    <SelectItem value="evenings-weekends">Evenings & Weekends</SelectItem>
                    <SelectItem value="flexible">Flexible</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="goals">Study Goals</Label>
                <Textarea
                  id="goals"
                  placeholder="What are you trying to achieve? (e.g., exam preparation, skill building, research)"
                  value={preferences.goals}
                  onChange={(e) => setPreferences(prev => ({ ...prev, goals: e.target.value }))}
                  rows={3}
                  data-testid="textarea-goals"
                />
              </div>

              <div>
                <Label htmlFor="location">Location Preference</Label>
                <Input
                  id="location"
                  placeholder="Campus, online, specific building, etc."
                  value={preferences.location}
                  onChange={(e) => setPreferences(prev => ({ ...prev, location: e.target.value }))}
                  data-testid="input-location"
                />
              </div>

              <div className="flex justify-end space-x-2 pt-4">
                <Button variant="outline" onClick={() => setIsUpdatingPreferences(false)}>
                  Cancel
                </Button>
                <Button 
                  onClick={handleFindMatches}
                  disabled={preferences.subjects.length === 0 || findMatchesMutation.isPending}
                  data-testid="button-find-matches"
                >
                  {findMatchesMutation.isPending ? (
                    <>
                      <i className="fas fa-spinner fa-spin mr-2"></i>
                      Finding Matches...
                    </>
                  ) : (
                    <>
                      <i className="fas fa-search mr-2"></i>
                      Find Matches
                    </>
                  )}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Current Matches */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <Card data-testid="potential-matches">
            <CardHeader>
              <CardTitle>Potential Study Partners</CardTitle>
            </CardHeader>
            <CardContent>
              {matchesLoading ? (
                <div className="space-y-4">
                  {[...Array(3)].map((_, i) => (
                    <Skeleton key={i} className="h-32" />
                  ))}
                </div>
              ) : !potentialMatches?.length ? (
                <div className="text-center py-8" data-testid="no-matches-message">
                  <i className="fas fa-users text-4xl text-muted-foreground mb-4"></i>
                  <p className="text-muted-foreground mb-4">
                    No matches found yet. Update your preferences to find study partners!
                  </p>
                  <Button 
                    onClick={() => setIsUpdatingPreferences(true)}
                    data-testid="button-set-preferences"
                  >
                    Set Preferences
                  </Button>
                </div>
              ) : (
                <div className="space-y-4">
                  {potentialMatches.map((match) => (
                    <Card key={match.id} className="border-l-4 border-l-primary" data-testid={`match-${match.id}`}>
                      <CardContent className="p-4">
                        <div className="flex items-start space-x-4">
                          <img 
                            src={match.avatar} 
                            alt={`${match.name} profile picture`} 
                            className="w-16 h-16 rounded-full border-2 border-border"
                          />
                          <div className="flex-1">
                            <div className="flex items-center justify-between mb-2">
                              <h3 className="font-semibold text-foreground text-lg">{match.name}</h3>
                              <Badge 
                                variant="secondary" 
                                className="bg-green-100 text-green-700"
                              >
                                {match.compatibility}% Match
                              </Badge>
                            </div>
                            
                            <p className="text-sm text-muted-foreground mb-3">{match.bio}</p>
                            
                            <div className="grid grid-cols-2 gap-4 mb-3">
                              <div>
                                <p className="text-xs font-medium text-muted-foreground">Subjects</p>
                                <div className="flex flex-wrap gap-1 mt-1">
                                  {match.subjects.map(subject => (
                                    <Badge key={subject} variant="outline" className="text-xs">
                                      {subject}
                                    </Badge>
                                  ))}
                                </div>
                              </div>
                              <div>
                                <p className="text-xs font-medium text-muted-foreground">Study Style</p>
                                <p className="text-sm text-foreground">{match.studyStyle}</p>
                              </div>
                              <div>
                                <p className="text-xs font-medium text-muted-foreground">Availability</p>
                                <p className="text-sm text-foreground">{match.availability}</p>
                              </div>
                              <div>
                                <p className="text-xs font-medium text-muted-foreground">Goals</p>
                                <p className="text-sm text-foreground line-clamp-2">{match.goals}</p>
                              </div>
                            </div>
                            
                            <div className="flex space-x-2">
                              <Button size="sm" data-testid={`button-message-${match.id}`}>
                                <i className="fas fa-envelope mr-1"></i>
                                Message
                              </Button>
                              <Button variant="outline" size="sm" data-testid={`button-connect-${match.id}`}>
                                <i className="fas fa-user-plus mr-1"></i>
                                Connect
                              </Button>
                              <Button variant="outline" size="sm" data-testid={`button-view-profile-${match.id}`}>
                                <i className="fas fa-eye mr-1"></i>
                                View Profile
                              </Button>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Match Filters */}
          <Card data-testid="match-filters">
            <CardHeader>
              <CardTitle>Filter Matches</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label>Minimum Compatibility</Label>
                <Select defaultValue="80">
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="70">70%+</SelectItem>
                    <SelectItem value="80">80%+</SelectItem>
                    <SelectItem value="90">90%+</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>Subject Focus</Label>
                <Select defaultValue="all">
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Subjects</SelectItem>
                    <SelectItem value="stem">STEM Only</SelectItem>
                    <SelectItem value="humanities">Humanities Only</SelectItem>
                    <SelectItem value="business">Business Only</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>Availability</Label>
                <Select defaultValue="any">
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="any">Any Time</SelectItem>
                    <SelectItem value="mornings">Mornings</SelectItem>
                    <SelectItem value="evenings">Evenings</SelectItem>
                    <SelectItem value="weekends">Weekends</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <Button variant="outline" className="w-full">
                <i className="fas fa-filter mr-2"></i>
                Apply Filters
              </Button>
            </CardContent>
          </Card>

          {/* Study Tips */}
          <Card data-testid="study-tips">
            <CardHeader>
              <CardTitle>Collaboration Tips</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3 text-sm">
                <div className="flex items-start space-x-2">
                  <i className="fas fa-lightbulb text-yellow-500 mt-1"></i>
                  <p className="text-muted-foreground">
                    Set clear goals and expectations for your study sessions
                  </p>
                </div>
                <div className="flex items-start space-x-2">
                  <i className="fas fa-clock text-blue-500 mt-1"></i>
                  <p className="text-muted-foreground">
                    Schedule regular study times that work for both partners
                  </p>
                </div>
                <div className="flex items-start space-x-2">
                  <i className="fas fa-handshake text-green-500 mt-1"></i>
                  <p className="text-muted-foreground">
                    Be respectful and communicate openly about study methods
                  </p>
                </div>
                <div className="flex items-start space-x-2">
                  <i className="fas fa-trophy text-purple-500 mt-1"></i>
                  <p className="text-muted-foreground">
                    Celebrate achievements and support each other through challenges
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Quick Actions */}
          <Card data-testid="quick-actions">
            <CardHeader>
              <CardTitle>Quick Actions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <Button variant="outline" className="w-full justify-start">
                <i className="fas fa-calendar-plus mr-2"></i>
                Schedule Study Session
              </Button>
              <Button variant="outline" className="w-full justify-start">
                <i className="fas fa-video mr-2"></i>
                Start Video Call
              </Button>
              <Button variant="outline" className="w-full justify-start">
                <i className="fas fa-share mr-2"></i>
                Share Study Materials
              </Button>
              <Button variant="outline" className="w-full justify-start">
                <i className="fas fa-chart-line mr-2"></i>
                Track Progress
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
