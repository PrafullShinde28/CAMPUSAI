import { useAuth } from '@/hooks/useAuth';
import { Sidebar } from './Sidebar';
import { Header } from './Header';
import { AuthButton } from './AuthButton';

interface LayoutProps {
  children: React.ReactNode;
}

export function Layout({ children }: LayoutProps) {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background" data-testid="loading-spinner">
        <div className="w-12 h-12 gradient-bg rounded-full flex items-center justify-center animate-pulse">
          <i className="fas fa-graduation-cap text-primary-foreground text-xl"></i>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background" data-testid="login-screen">
        <div className="text-center">
          <div className="w-20 h-20 gradient-bg rounded-full flex items-center justify-center mx-auto mb-6">
            <i className="fas fa-graduation-cap text-primary-foreground text-3xl"></i>
          </div>
          <h1 className="text-3xl font-bold text-foreground mb-2">CampusAI</h1>
          <p className="text-muted-foreground mb-8">AI-Powered Learning Platform</p>
          <AuthButton />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex bg-background" data-testid="app-layout">
      <Sidebar />
      <main className="flex-1 overflow-auto">
        <Header />
        <div className="p-6">
          {children}
        </div>
      </main>
    </div>
  );
}
