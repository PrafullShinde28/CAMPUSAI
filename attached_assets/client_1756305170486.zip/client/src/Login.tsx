import { auth } from "firebaseConfig";
import { signInWithEmailAndPassword } from "firebase/auth";
import { useNavigate } from "react-router-dom";

export default function Login() {
  const navigate = useNavigate();

  const handleLogin = async () => {
    try {
      await signInWithEmailAndPassword(auth, "test@example.com", "password123");
      navigate("/dashboard");
    } catch (err) {
      console.error(err);
    }
  };

  return <button onClick={handleLogin}>Login</button>;
}
